import cv2
import numpy as np
import sys
import os
import time
from django.conf import settings


# Handle CLI argument for username
if len(sys.argv) < 2:
    print("❌ No username provided.")
    time.sleep(3)
    sys.exit(1)

file_name = sys.argv[1]
print(f"📸 Starting face capture for {file_name}")

# Absolute path to this script's directory
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Haar cascade path
cascade_path = os.path.join(BASE_DIR, 'haarcascade_frontalface_alt.xml')
if not os.path.exists(cascade_path):
    print("❌ Haarcascade file not found!")
    time.sleep(3)
    sys.exit(1)

face_cascade = cv2.CascadeClassifier(cascade_path)

# Dataset save path
dataset_path = os.path.join(settings.BASE_DIR, 'Real-time-Face-Recognition-Project', 'face_dataset')

os.makedirs(dataset_path, exist_ok=True)
output_file = os.path.join(dataset_path, file_name + '.npy')

# Open webcam
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("❌ Cannot open webcam.")
    time.sleep(3)
    sys.exit(1)

skip = 0
face_data = []

while True:
    ret, frame = cap.read()
    if not ret:
        continue

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)

    if len(faces) == 0:
        cv2.imshow("Face Capture", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
        continue

    # Only the largest face
    faces = sorted(faces, key=lambda f: f[2] * f[3], reverse=True)
    x, y, w, h = faces[0]
    offset = 10
    face_section = frame[y-offset:y+h+offset, x-offset:x+w+offset]
    face_section = cv2.resize(face_section, (100, 100))

    skip += 1
    if skip % 10 == 0:
        face_data.append(face_section)
        print(f"✅ Captured {len(face_data)} samples")

    cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
    cv2.imshow("Face Capture", frame)

    if len(face_data) >= 50:
        break

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()

if face_data:
    face_data = np.array(face_data)
    face_data = face_data.reshape((face_data.shape[0], -1))
    np.save(output_file, face_data)
    print(f"✅ Saved face data to {output_file}")
else:
    print("❌ No face data captured.")

time.sleep(3)  # Pause so terminal doesn't instantly disappear
